package com.example.optionmenu;

import android.view.MenuItem;

public interface onclick {
    void onCreateOptionsMenu(MenuItem item);
}
