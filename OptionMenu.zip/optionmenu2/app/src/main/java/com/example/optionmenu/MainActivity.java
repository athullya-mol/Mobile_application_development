package com.example.optionmenu;

import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                        showToast("Item1 selected");
                        break;

            case R.id.item2:
                    showToast("Item2 selected");
                    break;

            case R.id.item3:

                    showToast("Item3 selected");
                    break;


            case R.id.subitem1:

                    showToast("subitem1 selected");
                    break;


            case R.id.subitem2:

                    showToast("SubItem2 selected");
                    break;

            default:

                    showToast("Invalid selected");
                    break;

        }
        return super.onOptionsItemSelected(item);
    }


    void showToast(String msg) {
        Context context = getApplicationContext();
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, msg, duration);
        toast.show();
    }
}